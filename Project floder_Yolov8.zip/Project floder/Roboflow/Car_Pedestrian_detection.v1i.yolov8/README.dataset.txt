# Car_Pedestrian_detection > 2024-09-02 5:41pm
https://universe.roboflow.com/image-detection-bbs6q/car_pedestrian_detection

Provided by a Roboflow user
License: CC BY 4.0

